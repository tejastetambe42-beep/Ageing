# 💳 Transaction Ageing Report — Dashboard

A premium fintech-style operations dashboard to replace daily ageing emails.
Inspired by internal dashboards at Stripe, Wise, and Revolut.

---

## 🚀 Quick Start (Local)

```bash
pip install streamlit pandas plotly openpyxl
streamlit run app.py
```

Then open: http://localhost:8501

---

## 🌐 Deployment Guide (Streamlit Community Cloud)

### Step 1 — Push to GitHub
```
your-repo/
├── app.py
├── requirements.txt
└── README.md
```

### Step 2 — Deploy
1. Go to https://share.streamlit.io
2. Sign in with GitHub → **New app**
3. Select repo, branch `main`, file `app.py`
4. Click **Deploy**

### Step 3 — Two Links Setup

| Link | Who Uses It | Purpose |
|------|-------------|---------|
| `https://your-app.streamlit.app` | **Your team** | Upload Excel daily via sidebar |
| `https://your-app.streamlit.app` | **Leadership** | View read-only dashboard |

> ℹ️ Both links point to the same URL. Once your team uploads the Excel,
> leadership sees the updated data on refresh. The uploaded file persists
> in `/home/clouduser/dashboard/latest_ageing.xlsx` on the server.

---

## 📋 Excel File Format

Expected columns (exact names):

| Column | Example |
|--------|---------|
| Date | 21/05/2026 or 20 05 2026 |
| Client name | Anand Pty Ltd |
| BD | Tejas |
| Corridor | MY / AU / SG |
| Transaction ID | PY97 |
| Amount USD | USD 288 or USD 2304.75 |
| Status | Compliance Queue / Error / Sent to Bank |
| Comments | Transaction under investigation… |
| Zendesk ID | 248 |
| Dependency | Bank / Client / Team / Compliance |

---

## 🎨 Status Color Mapping

| Status | Color |
|--------|-------|
| Error | 🔴 Red |
| Sent to Bank | 🔵 Blue |
| Compliance Verification | 🟠 Orange |
| PG Processing | 🟣 Purple |

## ⏱️ Ageing Highlights

| Ageing | Highlight |
|--------|-----------|
| 5–6 days | 🟠 Orange row |
| 7+ days | 🔴 Red row |

---

## 🔒 Notes

- No authentication is built in by default.
- For private leadership access, enable **Streamlit Cloud password protection**
  under Settings → Sharing → "Only specific people can view this app".
- The sidebar upload is always visible — instruct your team to use it daily.
