import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, date
import io, base64, os

# ─────────────────────────────────────────
# PAGE CONFIG
# ─────────────────────────────────────────
st.set_page_config(
    page_title="Transaction Ageing Report",
    page_icon="💳",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─────────────────────────────────────────
# GLOBAL CSS  – premium fintech look
# ─────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

html, body, [class*="css"] {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
}

/* ── page background ── */
.stApp { background: #f4f6fa; }

/* ── sidebar ── */
[data-testid="stSidebar"] {
    background: #0f172a !important;
}
[data-testid="stSidebar"] * { color: #cbd5e1 !important; }
[data-testid="stSidebar"] h1,
[data-testid="stSidebar"] h2,
[data-testid="stSidebar"] h3 { color: #f1f5f9 !important; }
[data-testid="stSidebar"] .stButton>button {
    background: #1e40af;
    color: #fff;
    border: none;
    border-radius: 8px;
    width: 100%;
    padding: 10px 0;
    font-weight: 600;
    font-size: 0.88rem;
    cursor: pointer;
    transition: background .2s;
}
[data-testid="stSidebar"] .stButton>button:hover { background: #1d4ed8; }

/* ── top header band ── */
.header-band {
    background: linear-gradient(135deg, #0f172a 0%, #1e3a5f 100%);
    border-radius: 18px;
    padding: 30px 36px 24px;
    margin-bottom: 22px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    box-shadow: 0 8px 32px rgba(15,23,42,0.18);
}
.header-left h1 {
    color: #f1f5f9;
    font-size: 1.75rem;
    font-weight: 700;
    margin: 0 0 4px 0;
    letter-spacing: -0.02em;
}
.header-left p {
    color: #94a3b8;
    font-size: 0.84rem;
    margin: 0;
}
.header-badge {
    background: rgba(255,255,255,0.08);
    border: 1px solid rgba(255,255,255,0.14);
    border-radius: 10px;
    padding: 14px 22px;
    text-align: center;
    min-width: 130px;
}
.header-badge .badge-label {
    color: #94a3b8;
    font-size: 0.72rem;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    margin-bottom: 4px;
}
.header-badge .badge-value {
    color: #f1f5f9;
    font-size: 1.25rem;
    font-weight: 700;
}

/* ── KPI cards ── */
.kpi-card {
    background: #ffffff;
    border-radius: 16px;
    padding: 20px 22px;
    border: 1px solid #e8edf5;
    box-shadow: 0 2px 12px rgba(15,23,42,0.06);
    position: relative;
    overflow: hidden;
    height: 100%;
    transition: box-shadow 0.2s;
}
.kpi-card:hover { box-shadow: 0 6px 24px rgba(15,23,42,0.12); }
.kpi-card .accent-bar {
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 4px;
    border-radius: 16px 16px 0 0;
}
.kpi-icon {
    font-size: 1.5rem;
    margin-bottom: 10px;
    display: block;
}
.kpi-label {
    font-size: 0.72rem;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: 0.07em;
    font-weight: 500;
    margin-bottom: 6px;
}
.kpi-count {
    font-size: 2.1rem;
    font-weight: 700;
    color: #111827;
    line-height: 1;
    margin-bottom: 6px;
}
.kpi-usd {
    font-size: 0.84rem;
    color: #4b5563;
    font-weight: 500;
}
.kpi-trend {
    margin-top: 10px;
    font-size: 0.78rem;
    display: flex;
    align-items: center;
    gap: 4px;
}

/* ── section card ── */
.section-card {
    background: #ffffff;
    border-radius: 16px;
    padding: 24px 26px;
    border: 1px solid #e8edf5;
    box-shadow: 0 2px 12px rgba(15,23,42,0.05);
    margin-bottom: 20px;
}
.section-title {
    font-size: 1rem;
    font-weight: 600;
    color: #111827;
    margin-bottom: 18px;
    display: flex;
    align-items: center;
    gap: 8px;
}

/* ── status pills ── */
.pill {
    display: inline-block;
    padding: 3px 11px;
    border-radius: 999px;
    font-size: 0.73rem;
    font-weight: 600;
    letter-spacing: 0.02em;
}
.pill-error      { background: #fef2f2; color: #b91c1c; border: 1px solid #fecaca; }
.pill-bank       { background: #eff6ff; color: #1d4ed8; border: 1px solid #bfdbfe; }
.pill-compliance { background: #fff7ed; color: #c2410c; border: 1px solid #fed7aa; }
.pill-pg         { background: #faf5ff; color: #6d28d9; border: 1px solid #ddd6fe; }
.pill-other      { background: #f3f4f6; color: #374151; border: 1px solid #e5e7eb; }

/* ── dependency pills ── */
.dep-bank       { background:#eff6ff; color:#1e40af; border:1px solid #bfdbfe; }
.dep-client     { background:#faf5ff; color:#6d28d9; border:1px solid #ddd6fe; }
.dep-team       { background:#f0fdf4; color:#166534; border:1px solid #bbf7d0; }
.dep-compliance { background:#fff7ed; color:#c2410c; border:1px solid #fed7aa; }
.dep-other      { background:#f3f4f6; color:#374151; border:1px solid #e5e7eb; }

/* ── ageing row highlight ── */
.row-orange { background: #fff8f0 !important; }
.row-red    { background: #fff5f5 !important; }

/* ── data table ── */
.stDataFrame { border-radius: 12px; overflow: hidden; }
[data-testid="stDataFrameResizable"] { font-size: 0.84rem; }

/* ── highlights box ── */
.highlights-card {
    background: linear-gradient(135deg, #0f172a 0%, #1e3a5f 100%);
    border-radius: 16px;
    padding: 26px 30px;
    color: #f1f5f9;
    box-shadow: 0 4px 20px rgba(15,23,42,0.15);
}
.highlights-card h3 {
    color: #f1f5f9;
    font-size: 1rem;
    font-weight: 600;
    margin-bottom: 16px;
    display: flex;
    align-items: center;
    gap: 8px;
}
.highlight-item {
    display: flex;
    align-items: flex-start;
    gap: 10px;
    margin-bottom: 12px;
    font-size: 0.875rem;
    color: #cbd5e1;
}
.highlight-dot {
    width: 8px; height: 8px;
    border-radius: 50%;
    background: #3b82f6;
    flex-shrink: 0;
    margin-top: 5px;
}
.ce-footer {
    margin-top: 18px;
    padding-top: 14px;
    border-top: 1px solid rgba(255,255,255,0.1);
    font-size: 0.875rem;
    color: #94a3b8;
    display: flex;
    align-items: center;
    gap: 8px;
}

/* ── filter bar ── */
.filter-bar {
    background: #f8fafc;
    border: 1px solid #e8edf5;
    border-radius: 12px;
    padding: 16px 18px;
    margin-bottom: 16px;
}

/* ── pagination ── */
.pagination-info {
    font-size: 0.82rem;
    color: #6b7280;
    text-align: right;
    padding-top: 6px;
}

/* ── divider ── */
hr { border-color: #e8edf5; margin: 8px 0 20px; }

/* ── dep summary table ── */
.dep-table { width: 100%; border-collapse: collapse; }
.dep-table th {
    font-size: 0.7rem;
    text-transform: uppercase;
    letter-spacing: 0.06em;
    color: #6b7280;
    font-weight: 600;
    padding: 8px 12px;
    background: #f8fafc;
    border-bottom: 1px solid #e8edf5;
    text-align: left;
}
.dep-table td {
    font-size: 0.84rem;
    padding: 10px 12px;
    border-bottom: 1px solid #f1f5f9;
    color: #374151;
}
.dep-table tr:last-child td { border-bottom: none; }
.dep-table tr:hover td { background: #f8fafc; }

/* hide streamlit branding */
#MainMenu { visibility: hidden; }
footer { visibility: hidden; }
.stDeployButton { display: none; }
</style>
""", unsafe_allow_html=True)


# ─────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────
STORED_FILE = "/home/claude/dashboard/latest_ageing.xlsx"

def parse_amount(val) -> float:
    if pd.isna(val): return 0.0
    s = str(val).replace("USD", "").replace("$", "").replace(",", "").strip()
    try: return float(s)
    except: return 0.0

def parse_date(val):
    if pd.isna(val): return pd.NaT
    s = str(val).strip()
    for fmt in ("%d/%m/%Y", "%d %m %Y", "%Y-%m-%d", "%m/%d/%Y", "%d-%m-%Y"):
        try: return datetime.strptime(s, fmt)
        except: continue
    try: return pd.to_datetime(s, dayfirst=True)
    except: return pd.NaT

def load_and_transform(file_bytes: bytes) -> pd.DataFrame:
    df = pd.read_excel(io.BytesIO(file_bytes))
    df.columns = [c.strip() for c in df.columns]

    rename = {
        "Client name": "Client Name",
        "Amount USD": "USD Value",
        "Amount $": "USD Value",
        "Amount": "USD Value",
    }
    df.rename(columns=rename, inplace=True)

    df["Date_parsed"] = df["Date"].apply(parse_date)
    df["USD Value"]   = df["USD Value"].apply(parse_amount)
    today             = pd.Timestamp(date.today())
    df["Ageing Days"] = (today - df["Date_parsed"]).dt.days.fillna(0).astype(int)
    df["Date_fmt"]    = df["Date_parsed"].apply(
        lambda x: x.strftime("%d %b %Y") if not pd.isna(x) else "—")
    df["Status Unified"] = df["Status"].apply(map_status)
    return df

def map_status(s) -> str:
    if not isinstance(s, str): return "Other"
    sl = s.strip().lower()
    if "error"       in sl: return "Error"
    if "sent to bank" in sl or "sent_to_bank" in sl: return "Sent to Bank"
    if "compliance"  in sl: return "Compliance Verification"
    if "pg"          in sl or "processing" in sl: return "PG Processing"
    return "Other"

def status_pill(s: str) -> str:
    m = {
        "Error": "pill-error",
        "Sent to Bank": "pill-bank",
        "Compliance Verification": "pill-compliance",
        "PG Processing": "pill-pg",
    }
    cls = m.get(s, "pill-other")
    return f'<span class="pill {cls}">{s}</span>'

def dep_pill(d: str) -> str:
    m = {"Bank": "dep-bank", "Client": "dep-client",
         "Team": "dep-team", "Compliance": "dep-compliance"}
    cls = m.get(str(d), "dep-other")
    return f'<span class="pill {cls}">{d}</span>'

def row_bg(days: int) -> str:
    if days >= 7: return "#fff0f0"
    if days >= 5: return "#fff8f0"
    return "#ffffff"

def fmt_usd(v: float) -> str:
    return f"${v:,.2f}"


# ─────────────────────────────────────────
# SIDEBAR
# ─────────────────────────────────────────
with st.sidebar:
    st.markdown("""
    <div style='text-align:center; padding: 10px 0 20px;'>
        <div style='font-size:2rem;'>💳</div>
        <div style='font-size:1rem; font-weight:700; color:#f1f5f9;'>Ageing Report</div>
        <div style='font-size:0.72rem; color:#64748b; margin-top:2px;'>Operations Dashboard</div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("### 📂 Upload Data")
    uploaded = st.file_uploader("Upload Excel (.xlsx)", type=["xlsx"], label_visibility="collapsed")

    if uploaded:
        file_bytes = uploaded.read()
        with open(STORED_FILE, "wb") as f:
            f.write(file_bytes)
        st.success("✅ File uploaded & saved")

    st.markdown("---")

    # Load data – from upload or stored file
    df_all = None
    if os.path.exists(STORED_FILE):
        with open(STORED_FILE, "rb") as f:
            df_all = load_and_transform(f.read())

    if df_all is not None:
        df_aged = df_all[df_all["Ageing Days"] >= 3].copy()

        st.markdown("### 📊 Quick Stats")
        st.markdown(f"""
        <div style='background:rgba(255,255,255,0.06); border-radius:10px; padding:14px 16px; margin-bottom:8px;'>
            <div style='font-size:0.72rem; color:#64748b; text-transform:uppercase; letter-spacing:.06em;'>Total Records</div>
            <div style='font-size:1.4rem; font-weight:700; color:#f1f5f9;'>{len(df_all)}</div>
        </div>
        <div style='background:rgba(255,255,255,0.06); border-radius:10px; padding:14px 16px; margin-bottom:8px;'>
            <div style='font-size:0.72rem; color:#64748b; text-transform:uppercase; letter-spacing:.06em;'>Aged ≥ 3 Days</div>
            <div style='font-size:1.4rem; font-weight:700; color:#f97316;'>{len(df_aged)}</div>
        </div>
        <div style='background:rgba(255,255,255,0.06); border-radius:10px; padding:14px 16px;'>
            <div style='font-size:0.72rem; color:#64748b; text-transform:uppercase; letter-spacing:.06em;'>Total Aged Value</div>
            <div style='font-size:1.2rem; font-weight:700; color:#34d399;'>{fmt_usd(df_aged["USD Value"].sum())}</div>
        </div>
        """, unsafe_allow_html=True)

        st.markdown("---")

    st.markdown("""
    <div style='font-size:0.72rem; color:#475569; text-align:center; padding-top:4px;'>
        <b>Internal Use Only</b><br>Upload latest Excel to refresh dashboard
    </div>
    """, unsafe_allow_html=True)


# ─────────────────────────────────────────
# NO DATA STATE
# ─────────────────────────────────────────
if df_all is None:
    st.markdown("""
    <div style='text-align:center; padding:80px 20px;'>
        <div style='font-size:3rem; margin-bottom:16px;'>📊</div>
        <h2 style='color:#1e3a5f; font-weight:700;'>Transaction Ageing Report</h2>
        <p style='color:#6b7280; max-width:400px; margin:12px auto 0;'>
            Upload your Excel file using the sidebar to load the dashboard.
        </p>
    </div>
    """, unsafe_allow_html=True)
    st.stop()


# ─────────────────────────────────────────
# DATA PREP
# ─────────────────────────────────────────
df_aged = df_all[df_all["Ageing Days"] >= 3].copy()
total_count = len(df_aged)
total_usd   = df_aged["USD Value"].sum()
last_refresh = datetime.now().strftime("%d %b %Y  •  %H:%M")

def kpi(df_src, key):
    if key == "Total":
        sub = df_src
    else:
        sub = df_src[df_src["Status Unified"] == key]
    return len(sub), sub["USD Value"].sum()


# ─────────────────────────────────────────
# HEADER BAND
# ─────────────────────────────────────────
count_e,  usd_e  = kpi(df_aged, "Error")
count_b,  usd_b  = kpi(df_aged, "Sent to Bank")
count_c,  usd_c  = kpi(df_aged, "Compliance Verification")
count_p,  usd_p  = kpi(df_aged, "PG Processing")

st.markdown(f"""
<div class="header-band">
    <div class="header-left">
        <h1>💳 Transaction Ageing Report</h1>
        <p>Payment Operations Control Center &nbsp;·&nbsp; Real-time ageing dashboard for leadership</p>
    </div>
    <div style="display:flex; gap:12px; flex-wrap:wrap; justify-content:flex-end;">
        <div class="header-badge">
            <div class="badge-label">🕐 Last Refreshed</div>
            <div class="badge-value" style="font-size:0.9rem;">{last_refresh}</div>
        </div>
        <div class="header-badge">
            <div class="badge-label">📋 Aged Transactions</div>
            <div class="badge-value">{total_count}</div>
        </div>
        <div class="header-badge">
            <div class="badge-label">💵 Total Aged Value</div>
            <div class="badge-value" style="font-size:1rem;">{fmt_usd(total_usd)}</div>
        </div>
    </div>
</div>
""", unsafe_allow_html=True)


# ─────────────────────────────────────────
# KPI CARDS ROW
# ─────────────────────────────────────────
kpi_data = [
    ("Total Ageing > 3 Days", total_count, total_usd,  "⏱️", "#3b82f6",  "Active monitoring"),
    ("Error",                  count_e,    usd_e,       "❗", "#ef4444",  "Requires immediate action"),
    ("Sent to Bank",           count_b,    usd_b,       "🏦", "#3b82f6",  "Awaiting bank response"),
    ("Compliance Verification",count_c,    usd_c,       "🛡️", "#f97316",  "RFI in progress"),
    ("PG Processing",          count_p,    usd_p,       "⚙️", "#8b5cf6",  "PG team investigating"),
]

cols = st.columns(5)
for col, (label, count, usd, icon, color, note) in zip(cols, kpi_data):
    with col:
        st.markdown(f"""
        <div class="kpi-card">
            <div class="accent-bar" style="background:{color};"></div>
            <span class="kpi-icon">{icon}</span>
            <div class="kpi-label">{label}</div>
            <div class="kpi-count">{count}</div>
            <div class="kpi-usd">{fmt_usd(usd)}</div>
            <div class="kpi-trend" style="color:{color};">
                <span>●</span>
                <span style="color:#6b7280; font-size:0.75rem;">{note}</span>
            </div>
        </div>
        """, unsafe_allow_html=True)

st.markdown("<div style='height:22px;'></div>", unsafe_allow_html=True)


# ─────────────────────────────────────────
# CHARTS + DEPENDENCY ROW
# ─────────────────────────────────────────
left, right = st.columns([3, 2])

with left:
    st.markdown("""
    <div class="section-card">
        <div class="section-title">📊 Transaction Breakdown by Status</div>
    """, unsafe_allow_html=True)

    breakdown = (
        df_aged[df_aged["Status Unified"].isin(
            ["Error", "Sent to Bank", "Compliance Verification", "PG Processing"])]
        .groupby("Status Unified")
        .agg(Count=("Transaction ID","count"), USD=("USD Value","sum"))
        .reset_index()
    )

    if breakdown.empty:
        st.info("No data for chart.")
    else:
        total_bk = breakdown["Count"].sum()
        breakdown["Pct"] = (breakdown["Count"] / total_bk * 100).round(1)
        breakdown["Label"] = breakdown.apply(
            lambda r: f"{r['Status Unified']} — {r['Count']} txns ({r['Pct']}%) · {fmt_usd(r['USD'])}", axis=1)

        color_map = {
            "Error":                   "#f87171",
            "Sent to Bank":            "#3b82f6",
            "Compliance Verification": "#fb923c",
            "PG Processing":           "#a855f7",
        }

        fig = px.pie(
            breakdown,
            names="Status Unified",
            values="Count",
            color="Status Unified",
            color_discrete_map=color_map,
            hole=0.62,
        )
        fig.update_traces(
            textinfo="percent",
            textfont_size=13,
            marker=dict(line=dict(color="#ffffff", width=2)),
            hovertemplate="<b>%{label}</b><br>Transactions: %{value}<br>Share: %{percent}<extra></extra>",
        )
        fig.update_layout(
            showlegend=True,
            legend=dict(
                orientation="v",
                x=1.01, y=0.5,
                font=dict(size=12, color="#374151"),
                itemgap=10,
            ),
            margin=dict(t=0, b=0, l=0, r=0),
            height=300,
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            annotations=[dict(
                text=f"<b>{total_count}</b><br><span style='font-size:10px'>Transactions</span>",
                x=0.38, y=0.5, font_size=16, showarrow=False, font_color="#111827"
            )],
        )
        st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})

    st.markdown("</div>", unsafe_allow_html=True)

with right:
    st.markdown("""
    <div class="section-card" style="height:100%;">
        <div class="section-title">🔗 Dependency Breakdown</div>
    """, unsafe_allow_html=True)

    if "Dependency" in df_aged.columns:
        dep_grp = (
            df_aged.groupby("Dependency", dropna=False)
            .agg(Count=("Transaction ID","count"), USD=("USD Value","sum"))
            .reset_index()
            .sort_values("Count", ascending=False)
        )
        dep_grp["Dependency"] = dep_grp["Dependency"].fillna("Unknown")

        rows_html = ""
        for _, row in dep_grp.iterrows():
            pill = dep_pill(str(row["Dependency"]))
            rows_html += f"""
            <tr>
                <td>{pill}</td>
                <td style='text-align:center; font-weight:600; color:#111827;'>{int(row['Count'])}</td>
                <td style='text-align:right; font-family:monospace; color:#374151;'>{fmt_usd(row['USD'])}</td>
            </tr>"""

        st.markdown(f"""
        <table class="dep-table">
            <thead>
                <tr>
                    <th>Dependency</th>
                    <th style='text-align:center;'>Txns</th>
                    <th style='text-align:right;'>USD Value</th>
                </tr>
            </thead>
            <tbody>{rows_html}</tbody>
        </table>
        """, unsafe_allow_html=True)

        # Mini bar chart
        dep_colors = {
            "Bank":"#3b82f6","Client":"#a855f7",
            "Team":"#22c55e","Compliance":"#f97316"
        }
        bar_colors = [dep_colors.get(d, "#94a3b8") for d in dep_grp["Dependency"]]
        fig2 = go.Figure(go.Bar(
            x=dep_grp["Dependency"],
            y=dep_grp["Count"],
            marker_color=bar_colors,
            text=dep_grp["Count"],
            textposition="outside",
            hovertemplate="<b>%{x}</b><br>Transactions: %{y}<extra></extra>",
        ))
        fig2.update_layout(
            margin=dict(t=20, b=0, l=0, r=0),
            height=180,
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            yaxis=dict(visible=False),
            xaxis=dict(tickfont=dict(size=12, color="#374151")),
            bargap=0.35,
            showlegend=False,
        )
        st.plotly_chart(fig2, use_container_width=True, config={"displayModeBar": False})
    else:
        st.info("No dependency column found.")
    st.markdown("</div>", unsafe_allow_html=True)


# ─────────────────────────────────────────
# TRANSACTIONS TABLE
# ─────────────────────────────────────────
st.markdown("""
<div class="section-card">
    <div class="section-title">📋 Aged Transactions &gt; 3 Days</div>
""", unsafe_allow_html=True)

# Filter row
fc1, fc2, fc3, fc4 = st.columns([3, 1.5, 1.5, 1.5])
with fc1:
    search = st.text_input("🔍 Search by Client, Txn ID, Comments, or Zendesk ID", "",
                           placeholder="Type to search...", label_visibility="collapsed")
with fc2:
    status_opts = ["All Statuses"] + sorted(df_aged["Status Unified"].dropna().unique().tolist())
    status_sel  = st.selectbox("Status", status_opts, label_visibility="collapsed")
with fc3:
    dep_opts = ["All Dependencies"] + sorted(df_aged["Dependency"].dropna().astype(str).unique().tolist())
    dep_sel  = st.selectbox("Dependency", dep_opts, label_visibility="collapsed")
with fc4:
    corridor_opts = ["All Corridors"] + sorted(df_aged["Corridor"].dropna().astype(str).unique().tolist())
    corridor_sel  = st.selectbox("Corridor", corridor_opts, label_visibility="collapsed")

df_filt = df_aged.copy()
if search:
    q = search.lower()
    df_filt = df_filt[
        df_filt["Client Name"].astype(str).str.lower().str.contains(q, na=False) |
        df_filt["Transaction ID"].astype(str).str.lower().str.contains(q, na=False) |
        df_filt["Comments"].astype(str).str.lower().str.contains(q, na=False) |
        df_filt["Zendesk ID"].astype(str).str.lower().str.contains(q, na=False)
    ]
if status_sel != "All Statuses":
    df_filt = df_filt[df_filt["Status Unified"] == status_sel]
if dep_sel != "All Dependencies":
    df_filt = df_filt[df_filt["Dependency"].astype(str) == dep_sel]
if corridor_sel != "All Corridors":
    df_filt = df_filt[df_filt["Corridor"].astype(str) == corridor_sel]

# Pagination
pa, pb, pc = st.columns([1, 1, 2])
with pa:
    rows_pp = st.selectbox("Rows per page", [10, 20, 50], label_visibility="collapsed")
total_rows  = len(df_filt)
total_pages = max(1, (total_rows - 1) // rows_pp + 1)
with pb:
    page_no = st.number_input("Page", min_value=1, max_value=total_pages,
                              value=1, step=1, label_visibility="collapsed")
with pc:
    st.markdown(f"""
    <div class="pagination-info">
        Showing {min((page_no-1)*rows_pp+1, total_rows)}–{min(page_no*rows_pp, total_rows)}
        of <b>{total_rows}</b> transactions &nbsp;·&nbsp; Page {page_no} of {total_pages}
    </div>""", unsafe_allow_html=True)

start = (page_no - 1) * rows_pp
df_page = df_filt.iloc[start : start + rows_pp].copy()

# Build HTML table
def comment_cell(txt):
    if pd.isna(txt) or str(txt).strip() == "": return "—"
    t = str(txt).strip()
    return t[:160] + "…" if len(t) > 160 else t

def ageing_badge(days):
    if days >= 7:
        return f'<span style="background:#fef2f2;color:#b91c1c;border:1px solid #fecaca;border-radius:6px;padding:2px 8px;font-weight:700;font-size:0.78rem;">🔴 {days}d</span>'
    elif days >= 5:
        return f'<span style="background:#fff7ed;color:#c2410c;border:1px solid #fed7aa;border-radius:6px;padding:2px 8px;font-weight:700;font-size:0.78rem;">🟠 {days}d</span>'
    else:
        return f'<span style="background:#f0fdf4;color:#166534;border:1px solid #bbf7d0;border-radius:6px;padding:2px 8px;font-weight:600;font-size:0.78rem;">{days}d</span>'

table_rows = ""
for _, r in df_page.iterrows():
    bg = row_bg(r["Ageing Days"])
    zdid = str(int(r["Zendesk ID"])) if not pd.isna(r.get("Zendesk ID", None)) else "—"
    table_rows += f"""
    <tr style="background:{bg};">
        <td style="white-space:nowrap; color:#374151;">{r['Date_fmt']}</td>
        <td><span style="background:#eff6ff;color:#1e40af;border-radius:6px;padding:2px 8px;font-size:0.78rem;font-weight:600;">{r.get('Corridor','—')}</span></td>
        <td style="font-weight:500; color:#111827;">{r.get('Client Name','—')}</td>
        <td style="color:#6b7280;">{r.get('BD','—')}</td>
        <td style="font-family:monospace; font-size:0.8rem; color:#374151;">{r.get('Transaction ID','—')}</td>
        <td>{status_pill(r['Status Unified'])}</td>
        <td style="max-width:300px; color:#4b5563; font-size:0.82rem; line-height:1.4;">{comment_cell(r.get('Comments',''))}</td>
        <td style="text-align:center;"><a href="https://support.zendesk.com/agent/tickets/{zdid}" target="_blank" style="color:#3b82f6; text-decoration:none; font-weight:500;">#{zdid}</a></td>
        <td>{dep_pill(str(r.get('Dependency','—')))}</td>
        <td style="text-align:right; font-weight:600; font-family:monospace; color:#111827;">{fmt_usd(r['USD Value'])}</td>
        <td style="text-align:center;">{ageing_badge(r['Ageing Days'])}</td>
    </tr>"""

st.markdown(f"""
<div style="overflow-x:auto; border-radius:12px; border:1px solid #e8edf5;">
<table style="width:100%; border-collapse:collapse; font-size:0.84rem;">
    <thead>
        <tr style="background:#f8fafc; border-bottom:2px solid #e8edf5;">
            <th style="padding:12px 14px; text-align:left; font-size:0.7rem; text-transform:uppercase; letter-spacing:.06em; color:#6b7280; font-weight:600; white-space:nowrap;">Date</th>
            <th style="padding:12px 14px; text-align:left; font-size:0.7rem; text-transform:uppercase; letter-spacing:.06em; color:#6b7280; font-weight:600;">Corridor</th>
            <th style="padding:12px 14px; text-align:left; font-size:0.7rem; text-transform:uppercase; letter-spacing:.06em; color:#6b7280; font-weight:600;">Client Name</th>
            <th style="padding:12px 14px; text-align:left; font-size:0.7rem; text-transform:uppercase; letter-spacing:.06em; color:#6b7280; font-weight:600;">BD</th>
            <th style="padding:12px 14px; text-align:left; font-size:0.7rem; text-transform:uppercase; letter-spacing:.06em; color:#6b7280; font-weight:600;">Txn ID</th>
            <th style="padding:12px 14px; text-align:left; font-size:0.7rem; text-transform:uppercase; letter-spacing:.06em; color:#6b7280; font-weight:600;">Status</th>
            <th style="padding:12px 14px; text-align:left; font-size:0.7rem; text-transform:uppercase; letter-spacing:.06em; color:#6b7280; font-weight:600; min-width:240px;">Comments</th>
            <th style="padding:12px 14px; text-align:center; font-size:0.7rem; text-transform:uppercase; letter-spacing:.06em; color:#6b7280; font-weight:600;">Zendesk</th>
            <th style="padding:12px 14px; text-align:left; font-size:0.7rem; text-transform:uppercase; letter-spacing:.06em; color:#6b7280; font-weight:600;">Dependency</th>
            <th style="padding:12px 14px; text-align:right; font-size:0.7rem; text-transform:uppercase; letter-spacing:.06em; color:#6b7280; font-weight:600;">USD Value</th>
            <th style="padding:12px 14px; text-align:center; font-size:0.7rem; text-transform:uppercase; letter-spacing:.06em; color:#6b7280; font-weight:600;">Ageing</th>
        </tr>
    </thead>
    <tbody>
        {table_rows if table_rows else '<tr><td colspan="11" style="text-align:center;padding:40px;color:#9ca3af;">No transactions match the current filters.</td></tr>'}
    </tbody>
</table>
</div>
""", unsafe_allow_html=True)

st.markdown("</div>", unsafe_allow_html=True)  # close section-card


# ─────────────────────────────────────────
# AGEING DISTRIBUTION CHART
# ─────────────────────────────────────────
if not df_aged.empty and df_aged["Ageing Days"].nunique() > 1:
    st.markdown('<div class="section-card"><div class="section-title">📈 Ageing Distribution</div>', unsafe_allow_html=True)

    bins   = [3, 5, 7, 10, 999]
    labels = ["3–4 Days", "5–6 Days", "7–9 Days", "10+ Days"]
    df_aged["Ageing Bucket"] = pd.cut(df_aged["Ageing Days"], bins=bins, labels=labels, right=False)
    bucket_df = df_aged.groupby("Ageing Bucket", observed=True).agg(
        Count=("Transaction ID","count"), USD=("USD Value","sum")).reset_index()

    fig3 = go.Figure(go.Bar(
        x=bucket_df["Ageing Bucket"],
        y=bucket_df["Count"],
        marker_color=["#22c55e", "#f97316", "#ef4444", "#7f1d1d"],
        text=bucket_df["Count"],
        textposition="outside",
        hovertemplate="<b>%{x}</b><br>Transactions: %{y}<extra></extra>",
    ))
    fig3.update_layout(
        margin=dict(t=10, b=0, l=0, r=0),
        height=220,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        yaxis=dict(gridcolor="#f1f5f9", tickfont=dict(color="#9ca3af", size=11)),
        xaxis=dict(tickfont=dict(color="#374151", size=12)),
        bargap=0.3,
    )
    st.plotly_chart(fig3, use_container_width=True, config={"displayModeBar": False})
    st.markdown("</div>", unsafe_allow_html=True)


# ─────────────────────────────────────────
# KEY HIGHLIGHTS
# ─────────────────────────────────────────
highlights = [
    ("Majority of ageing driven by partner bank dependency and downstream investigations.", "🏦"),
    ("No significant increase in overall ageing trend observed in the current period.", "📊"),
    ("Compliance queue remains stable — RFIs are actively tracked with clients.", "🛡️"),
    ("High-value transactions are under active monitoring by the Operations and CE teams.", "💰"),
]

items_html = ""
for text, icon in highlights:
    items_html += f"""
    <div class="highlight-item">
        <div class="highlight-dot"></div>
        <span>{icon}&nbsp;&nbsp;{text}</span>
    </div>"""

st.markdown(f"""
<div class="highlights-card">
    <h3>📌 Key Highlights</h3>
    {items_html}
    <div class="ce-footer">
        <span>🔍</span>
        <span><b style="color:#f1f5f9;">CE team is closely monitoring these transactions.</b>
        &nbsp;All critical cases are escalated and under active resolution.</span>
    </div>
</div>
""", unsafe_allow_html=True)

st.markdown("<div style='height:30px;'></div>", unsafe_allow_html=True)
